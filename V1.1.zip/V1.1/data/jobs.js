// V1-inspirerede jobs + lavere bruttolønninger
export const JOBS = [
  { title: "Netto medarbejder", gross: 19000 },
  { title: "Butiksassistent", gross: 20500 },
  { title: "Lager- og logistikmedarbejder", gross: 21500 },
  { title: "Chauffør (varebil)", gross: 22500 },
  { title: "Køkkenmedhjælper", gross: 20500 },
  { title: "Rengøringsassistent", gross: 20000 },
  { title: "Sosu-hjælper", gross: 23000 },
  { title: "Sosu-assistent", gross: 25500 },
  { title: "Pædagogmedhjælper", gross: 23500 },
  { title: "Kontorassistent", gross: 24500 },
  { title: "Tømrer", gross: 28500 },
  { title: "Murer", gross: 29000 },
  { title: "Elektriker", gross: 30000 },
  { title: "VVS-montør", gross: 30500 },
  { title: "Lastbilchauffør", gross: 28500 },
  { title: "IT-supporter", gross: 31000 },
  { title: "Lærer", gross: 32000 },
  { title: "Sygeplejerske", gross: 32500 },
  { title: "Ingeniør", gross: 35000 },
  { title: "Læge (forenklet)", gross: 35000 }
];
